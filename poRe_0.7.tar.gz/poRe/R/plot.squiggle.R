plot.squiggle <-
function(events, minseconds=0, maxseconds=15, mar=c(4,4,3,0.5), lwd=1.5) {

	# create a new column, relstart, that is the
	# start of the event in relation to the first event
	events$relstart <- events$start-min(events$start)

	# filter the events between minseconds and maxseconds
	# after the start
	events <- events[events$relstart<=maxseconds&events$relstart>=minseconds,]

	# a vector times
	times <- vector()

	# a vector of signal
	means <- vector()

	# for each event
	for (i in 1:nrow(events)) {

		# the mean signal lasts from relstart
		# to relstart + length
		times <- append(times, events$relstart[i])
		means <- append(means, events$mean[i])
		if (i==nrow(events)) {
			times <- append(times, events$relstart[i])
		} else {
			times <- append(times, events$relstart[i+1])
		}
		means <- append(means, events$mean[i])

	}

	# plot
	par(mar=mar)
	plot(times,means,type="l", lwd=lwd, ylab="mean signal", xlab="seconds")


}
