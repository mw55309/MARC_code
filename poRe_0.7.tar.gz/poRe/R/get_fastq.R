get_fastq <-
function(f5, which="all") {
	
	# a list to return
	ret <- list()

	# open file handle
	fid <- H5Fopen(f5)

	if (typeof(fid) != "S4") {
		return(FALSE)
	}

	# If it exists and they ask for it, template
	if (f5.exists(f5,"/Analyses/Basecall_2D_000/BaseCalled_template") && (which=="all" || which=="template")) {

		# extract the Fastq and store it in ret
		gid <- H5Gopen(fid, "/Analyses/Basecall_2D_000/BaseCalled_template")
		did <- H5Dopen(gid, "Fastq")
		fq <- (H5Dread(did))
		ret[["template"]] <- fq

		H5Dclose(did)
		H5Gclose(gid)
	}


	# If it exists and they ask for it, complement
	if (f5.exists(f5,"/Analyses/Basecall_2D_000/BaseCalled_complement") && (which=="all" || which=="complement")) {

		# extract the Fastq and store it in ret
		gid <- H5Gopen(fid, "/Analyses/Basecall_2D_000/BaseCalled_complement")
		did <- H5Dopen(gid, "Fastq")
		fq <- (H5Dread(did))
		ret[["complement"]] <- fq

		H5Dclose(did)
		H5Gclose(gid)
	}

	# If it exists and they ask for it, 2D
	if (f5.exists(f5,"/Analyses/Basecall_2D_000/BaseCalled_2D") && (which=="all" || which=="2D")) {

		# extract the fastq and store it in ret
		gid <- H5Gopen(fid, "/Analyses/Basecall_2D_000/BaseCalled_2D")
		did <- H5Dopen(gid, "Fastq")
		fq <- (H5Dread(did))
		ret[["2D"]] <- fq

		H5Dclose(did)
		H5Gclose(gid)
	}

	# deal with cDNA
	if (f5.exists(f5,"/Analyses/Basecall_1D_CDNA_000/BaseCalled_template") && (which=="all" || which=="template")) {

		# extract the fastq and store it in ret
		gid <- H5Gopen(fid, "/Analyses/Basecall_1D_CDNA_000/BaseCalled_template")
		did <- H5Dopen(gid, "Fastq")
		fq <- (H5Dread(did))
		ret[["template"]] <- fq

		H5Dclose(did)
		H5Gclose(gid)
	}


	# close and return
	H5Fclose(fid)
	return(ret)

}
