get_fast5_info <-
function(f5) {

	# a vector to return
	ret <- vector(mode="character")

	# open file handle
	fid <- H5Fopen(f5)

	if (typeof(fid) != "S4") {
        	return(rep("",24))
    	}

	top.group <- "/Analyses/Basecall_2D_000/"
	if (f5.exists(f5,"/Analyses/Basecall_1D_CDNA_000")) {
		top.group <- "/Analyses/Basecall_1D_CDNA_000/"
	}

	# extract information about the analysis
	if (f5.exists(f5,top.group)) {

		# get attributes from the Analyses group
		gid <- H5Gopen(fid, top.group)

		# name of the analysis
		aid <- H5Aopen(gid, "name")
		ret[1] <- (H5Aread(aid))
		H5Aclose(aid)

		# timestamp
		aid <- H5Aopen(gid, "time_stamp")
		ret[2] <- (H5Aread(aid))
		H5Aclose(aid)

		# version
		aid <- H5Aopen(gid, "version")
		ret[3] <- (H5Aread(aid))
		H5Aclose(aid)

		H5Gclose(gid)
	} else {
		ret <- c("","","")
	}

	# get Fastq sequence lengths by measuring the
	# length of the fastq sequences themselves
	for (group in c("BaseCalled_template","BaseCalled_complement","BaseCalled_2D")) {
		if (f5.exists(f5,paste(top.group, group, sep=""))) {
			gid <- H5Gopen(fid, paste(top.group, group, sep=""))
			did <- H5Dopen(gid, "Fastq")

			# split on "\n"
			four <- strsplit((H5Dread(did)), "\n")
			
			# store the length of the sequence
			ret <- c(ret, nchar(four[[1]][2]))

			H5Dclose(did)
			H5Gclose(gid)
		} else {
			ret <- c(ret,"")
		}
	}
	
	# get attributes from the Summary template and complement
	# including called_events, mean_qscore and num_events
	for (group in c("basecall_1d_template","basecall_1d_complement")) {

		tgs <- paste(top.group, "Summary/", sep="")

		if (f5.exists(f5,paste(tgs, group, sep=""))) {
			gid <- H5Gopen(fid, paste(tgs, group, sep=""))
			for (attr in c("called_events","mean_qscore","num_events")) {
				aid <- H5Aopen(gid, attr)
				ret <- append(ret, (H5Aread(aid)))
				H5Aclose(aid)
			}
			H5Gclose(gid)
		} else {
			ret <- c(ret,"","","")
		}
	}



	# get attributes from the basecall_2 dsummary group
	# including mean_qscore and sequence_length
	for (group in c("basecall_2d")) {
		tgs <- paste(top.group, "Summary/", sep="")
		if (f5.exists(f5,paste(tgs, group, sep=""))) {
			gid <- H5Gopen(fid, paste(tgs, group, sep=""))
			for (attr in c("mean_qscore","sequence_length")) {
				aid <- H5Aopen(gid, attr)
				ret <- append(ret, (H5Aread(aid)))
				H5Aclose(aid)
			}
			H5Gclose(gid)
		} else {
			ret <- c(ret,"","")
		}
	}


	# get the channel number
	# this may be embedded in the read_id group (if present)
	# or the channel_id group (if present
	channel_number <- NA
	for (group in c("read_id","channel_id")) {
		if (is.na(channel_number)) {
			if (f5.exists(f5,paste("/UniqueGlobalKey/", group, sep=""))) {
				gid <- H5Gopen(fid, paste("/UniqueGlobalKey/", group, sep=""))
				for (attr in c("channel_number")) {
					aid <- H5Aopen(gid, attr)
					channel_number <- (H5Aread(aid))
					H5Aclose(aid)
				}
				H5Gclose(gid)
			} else {
				channel_number <- NA
			}
		}
	}
	ret <- c(ret, channel_number)
	


	# get the attributes from tracking_id group
	for (group in c("tracking_id")) {

		if(f5.exists(f5,paste("/UniqueGlobalKey/", group, sep=""))) {
			gid <- H5Gopen(fid, paste("/UniqueGlobalKey/", group, sep=""))
			for (attr in c("asic_id","asic_temp","device_id","exp_script_purpose","exp_start_time","flow_cell_id","heatsink_temp","run_id","version_name")) {
				aid <- H5Aopen(gid, attr)
				ret <- append(ret, (H5Aread(aid)))
				H5Aclose(aid)
			}
			H5Gclose(gid)
		} else {
			ret <- c(ret,"","","","","","","","","")
		}
	}

	# close file handle
	H5Fclose(fid)
	
	# return
	return(ret)

}
