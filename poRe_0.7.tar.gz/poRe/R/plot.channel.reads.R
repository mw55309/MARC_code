plot.channel.reads <-
function(x, maxchannels=512, col.col="black",col.border="black") {

	# count reads by channel
	read.counts <- aggregate(x$clen, by=list(x$channel), length)

	# there may be more channels than are reported, so we merge
	# with a false data.frame and set missing values to 0
	df <- merge(data.frame(channel=1:512), read.counts, by.x="channel", by.y="Group.1", all.x=TRUE)	
	df$x[is.na(df$x)] <- 0

	# rename the columns
	colnames(df) <- c("channel","num_reads")

	# draw the barplot
	barplot(df$num_reads, names=df$channel, xaxt="n", ylab="num reads", space=c(0,0), col=col.col, border=col.border)

	# add an axis that makes sense
	labs <- seq(0,maxchannels,by=12)
	labs <- labs[2:length(labs)]
	axis(side=1, at=labs, labels=labs, ps=8, las=2)
	axis(side=1, at=maxchannels/2, labels="channel", line=1.5, tick=FALSE)

	# return the data
	return(df)	

}
