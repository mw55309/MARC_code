extract.run.fasta <-
function(dir=getwd(), dest=paste(dir,"extracted",sep="/")) {

	
	# find all the .fast5 files in dir
	f5files <- dir(path=dir, pattern="\\.fast5", full.names=TRUE)

	# attempt to create dest if it doesn't exist
	if (file.exists(dest)) {

	} else {
		dir.create(dest, recursive=TRUE)
	}

	# for each fast5 file
	for (f5 in f5files) {
		#  extract fastq into dest
		fast52fasta(f5, dest=dest)
	}

}
