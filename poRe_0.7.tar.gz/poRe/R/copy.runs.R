copy.runs <- function(dir=getwd(), dest=getwd()) {


	# list to hold the list of run folders that
	# are created
	runs <- list()

	# find all the .fast5 files in dir
	f5files <- dir(path=dir, pattern="\\.fast5", full.names=TRUE)

	for (f5 in f5files) {

		# open file handle
		fid <- H5Fopen(f5)

		if (typeof(fid) != "S4") {
			next()
		}

		# default run_id
		run_id = "no_run_id"

		# if tracking_id is in there
		# open it and extract run_id
		if(f5.exists(f5, "/UniqueGlobalKey/tracking_id")) {
			gid <- H5Gopen(fid, "/UniqueGlobalKey/tracking_id")
			
			aid <- H5Aopen(gid, "run_id")
			run_id <- (H5Aread(aid))
			H5Aclose(aid)

			H5Gclose(gid)
		}

		# default analysis version
		analysis <- "no_analysis"

		# if the name and version of the
		# analysis are in there, get them
		if (f5.exists(f5,"/Analyses/Basecall_2D_000")) {

			# get attributes from the Analyses group
			gid <- H5Gopen(fid, "/Analyses/Basecall_2D_000")

			# name of the analysis
			aid <- H5Aopen(gid, "name")
			aname <- (H5Aread(aid))
			H5Aclose(aid)

			# version
			aid <- H5Aopen(gid, "version")
			aversion <- (H5Aread(aid))
			H5Aclose(aid)

			H5Gclose(gid)

			# analysis becomes a paste of
			# the analysis name and version
			# e.g. metrichor_0.7.1
			analysis <- paste(aname,aversion,sep="_")
		}

		# deal with cDNA
		if (f5.exists(f5,"/Analyses/Basecall_1D_CDNA_000")) {

			# get attributes from the Analyses group
			gid <- H5Gopen(fid, "/Analyses/Basecall_1D_CDNA_000")

			# name of the analysis
			aid <- H5Aopen(gid, "name")
			aname <- (H5Aread(aid))
			H5Aclose(aid)

			# version
			aid <- H5Aopen(gid, "version")
			aversion <- (H5Aread(aid))
			H5Aclose(aid)

			H5Gclose(gid)

			# analysis becomes a paste of
			# the analysis name and version
			# e.g. metrichor_0.7.1
			analysis <- paste(aname,aversion,sep="_")
		}		

	
		# if the run directory already exists within dest
		if (file.exists(paste(dest, run_id, sep="/"))) {

			# if the analysis directory exists within dest/run
			# copy the file and add the directory to runs
			if (file.exists(paste(dest,run_id,analysis, sep="/"))) {
				file.copy(f5, paste(dest,run_id,analysis,basename(f5),sep="/"))
				runs[[paste(dest,run_id,analysis,sep="/")]] <- 1
			} else {
				# create analysis dir and copy the file
				dir.create(paste(dest,run_id,analysis,sep="/"))
				file.copy(f5, paste(dest,run_id,analysis,basename(f5),sep="/"))
				runs[[paste(dest,run_id,analysis,sep="/")]] <- 1
			}
		} else {
			# create the run folder
			dir.create(paste(dest,run_id,sep="/"))

			# create analysis folder within run folder
			# copy the file and add the directory to runs
			dir.create(paste(dest,run_id,analysis,sep="/"))
			file.copy(f5, paste(dest,run_id,analysis,basename(f5),sep="/"))
			runs[[paste(dest,run_id,analysis,sep="/")]] <- 1
		}

		# close file handle
		H5Fclose(fid)

	}

	# return a vector containing the newly created run folders
	return(names(runs))

}
