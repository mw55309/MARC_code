get.align <- function(f5) {

        fid <- H5Fopen(f5)

	if (typeof(fid) != "S4") {
		return(FALSE)
	}

        gid <- H5Gopen(fid, "/Analyses/Basecall_2D_000/BaseCalled_2D/");

        did <- H5Dopen(gid, "Alignment")

        aln <- (H5Dread(did, bit64conversion = "bit64"))

        H5Dclose(did)
        H5Gclose(gid)
        H5Fclose(fid)

        return(aln)
}
