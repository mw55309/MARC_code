get.events <-
function(f5) {

	# a list to return
	ret <- list()

	# open file handle
	fid <- H5Fopen(f5)

	if (typeof(fid) != "S4") {
		return(FALSE)
	}

	# template
	if (f5.exists(f5,"/Analyses/Basecall_2D_000/BaseCalled_template")) {
	
		# get the template events
		gid <- H5Gopen(fid, "/Analyses/Basecall_2D_000/BaseCalled_template")
		did <- H5Dopen(gid, "Events")
		events <- (H5Dread(did, bit64conversion='bit64'))

		# store them in ret
		ret[["template"]] <- events

		# close
		H5Dclose(did)
		H5Gclose(gid)

	}

	# complement
	if (f5.exists(f5,"/Analyses/Basecall_2D_000/BaseCalled_complement")) {
	
		# get the complement events
		gid <- H5Gopen(fid, "/Analyses/Basecall_2D_000/BaseCalled_complement")
		did <- H5Dopen(gid, "Events")
		events <- (H5Dread(did, bit64conversion='bit64'))

		# store them in ret
		ret[["complement"]] <- events

		# close
		H5Dclose(did)
		H5Gclose(gid)

	}

	# cDNA
	if (f5.exists(f5,"/Analyses/Basecall_1D_CDNA_000/BaseCalled_template")) {
	
		# get the template events
		gid <- H5Gopen(fid, "/Analyses/Basecall_1D_CDNA_000/BaseCalled_template")
		did <- H5Dopen(gid, "Events")
		events <- (H5Dread(did, bit64conversion='bit64'))

		# store them in ret
		ret[["template"]] <- events

		# close
		H5Dclose(did)
		H5Gclose(gid)

	}

	# close file
	H5Fclose(fid)

	# return
	return(ret)

}
