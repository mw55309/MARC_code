run.summary.stats <-
function(x, rundir=NULL) {

	# a vector to store data in
	ret <- vector()

	# calculate a number of useful statistics

	# number of templates
	ret <- append(ret,length(x$tlen[x$tlen>0]))

	# max template
	ret <- append(ret, max(x$tlen))

	# min template
	ret <- append(ret, min(x$tlen[x$tlen>0]))

	# mean template
	ret <- append(ret, round(mean(x$tlen[x$tlen>0])))

	# sd template
	ret <- append(ret, round(sd(x$tlen[x$tlen>0])))

	# number of complements
	ret <- append(ret,length(x$clen[x$clen>0]))

	# max complement
	ret <- append(ret, max(x$clen))

	# min complement
	ret <- append(ret, min(x$clen[x$clen>0]))

	# mean complement
	ret <- append(ret, round(mean(x$clen[x$clen>0])))

	# sd complement
	ret <- append(ret, round(sd(x$clen[x$clen>0])))

	# number of failed 2d
	ret <- append(ret,length(x$tlen[x$tlen>0&x$clen>0&x$len2d==0]))

	# number of 2d
	ret <- append(ret,length(x$len2d[x$len2d>0]))

	# max 2d
	ret <- append(ret, max(x$len2d))

	# min 2d
	ret <- append(ret, min(x$len2d[x$len2d>0]))

	# mean 2d
	ret <- append(ret, round(mean(x$len2d[x$len2d>0])))

	# sd 2d
	ret <- append(ret, round(sd(x$len2d[x$len2d>0])))

	# create the data frame
	df <- data.frame(stat=c("Templates: Number","Templates: Max length","Templates: Min length","Templates: Mean length","Templates: SD length",
				"Complements: Number","Complements: Max length","Complements: Min length","Complements: Mean length","Complements: SD length",
				"2D failed", "2D: Number","2D: Max length","2D: Min length","2D: Mean length","2D: SD length"), value=ret, stringsAsFactors=FALSE)

	if(!is.null(rundir)) {
		f5count <- length(dir(path=rundir, pattern="\\.fast5", full.names=TRUE))
		df <- rbind(c("Fast5: Number",f5count),df)
	}

	# return it
	return(df)

}
