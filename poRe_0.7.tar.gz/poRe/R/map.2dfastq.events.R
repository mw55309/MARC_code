map.2dfastq.events <- function(f5) {

	# get 2D fastq
	fq <- get_fastq(f5, which="2D")
	if (typeof(fq) == "logical") {
		return(FALSE)
	}

	# link events to 2D kmers
	aln <- get.kmer.events(f5)
	if (typeof(aln) == "logical") {
		return(FALSE)
	}

	# get 2D sequence
	four <- strsplit(fq$'2D', "\n")
	seq <- four[[1]][2]

	# add 2D kmer position to the alignment table
	kmer.length <- 5
	seq.pos     <- 1
	scan        <- 10

	kmer.pos    <- rep("NA", length=nrow(aln))

	# iterate over aln object
	for (i in 1:nrow(aln)) {

		current.kmer <- aln$kmer[i]
	
		current.pos  <- seq.pos
		kmer.2d      <- substr(seq, seq.pos, seq.pos + kmer.length - 1)
		while(kmer.2d != current.kmer && (current.pos - seq.pos) <= scan) {
			current.pos <- current.pos + 1
			kmer.2d     <- substr(seq, current.pos, current.pos + kmer.length - 1)
		}

		# if we have 
		if (kmer.2d == current.kmer) {
			seq.pos <- current.pos
			kmer.pos[i] <- seq.pos
		}
	
	}

	aln$kmer.pos <- kmer.pos

	return(aln)
}