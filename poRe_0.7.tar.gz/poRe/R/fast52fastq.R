fast52fastq <-
function(f5, dest=getwd(), which="all") {

	# extract the filename from the full path
	fbase <- basename(f5)

	# get a list containing fastq data from f5
	# which can be "all", "template" or "complement"
	lst <- get_fastq(f5, which=which)

	if (typeof(lst) != "list") {
		return(FALSE)
	}

	# if we chose template and it exists
	if ((which=="all" || which=="template") && "template" %in% names(lst)) {

		# create an output filename
		fname <- sub(".fast5", ".template.fastq", fbase)

		# create the full out path
		out <- paste(dest,fname,sep="/")

		# write the template
		write.table(lst[["template"]], out, col.names=FALSE, row.names=FALSE, quote=FALSE)

	}	

	# if we chose complement and it exists
	if ((which=="all" || which=="complement") && "complement" %in% names(lst)) {

		# create an output filename
		fname <- sub(".fast5", ".complement.fastq", fbase)

		# create the full out path
		out <- paste(dest,fname,sep="/")

		# write the complement
		write.table(lst[["complement"]], out, col.names=FALSE, row.names=FALSE, quote=FALSE)

	}	

	# if we chose 2D and it exists
	if ((which=="all" || which=="2D") && "2D" %in% names(lst)) {

		
		# create an output filename
		fname <- sub(".fast5", ".2D.fastq", fbase)

		# create full output path
		out <- paste(dest,fname,sep="/")

		# write the 2D read
		write.table(lst[["2D"]], out, col.names=FALSE, row.names=FALSE, quote=FALSE)

	}	

}
