plot.channel.yield <-
function(x, maxchannels=512, col.col="black",col.border="black", which="tlen") {

	# sum yield by channel - which tells us whether to use template (tlen), complement (clen) or 2D (len2d)
	read.yield <- aggregate(x[,which], by=list(x$channel), sum)

	# there may be more channels than are reported, so we merge
	# with a false data.frame and set missing values to 0	
	df <- merge(data.frame(channel=1:512), read.yield, by.x="channel", by.y="Group.1", all.x=TRUE)	
	df$x[is.na(df$x)] <- 0

	# set the column names
	colnames(df) <- c("channel","yield")

	# draw the barplot
	barplot(df$yield, names=df$channel, xaxt="n", ylab="yield", space=c(0,0), col=col.col, border=col.border)

	# add an axis that makes sense
	labs <- seq(0,maxchannels,by=12)
	labs <- labs[2:length(labs)]
	axis(side=1, at=labs, labels=labs, ps=8, las=2)
	axis(side=1, at=maxchannels/2, labels="channel", line=1.5, tick=FALSE)

	# return the data
	return(df)	

}
