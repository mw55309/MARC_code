plot.length.histogram <-
function(x, breaks=100, mar=c(4,4,3,0.5), titles=c("template","complement","2D"), colours=c("blue","yellow","red")) {

	# split into 1 row, 3 columns
	split.screen(c(1,3))

	# plot histograms of template, complement and 2D in turn
	# counting only those that are >0
	screen(1)
	par(mar=mar)
	hist(as.numeric(x$tlen[x$tlen>0]), breaks=breaks, main=titles[1], xlab="length", col=colours[1])
	screen(2)
	par(mar=mar)
	hist(as.numeric(x$clen[x$clen>0]), breaks=breaks, main=titles[2], xlab="length", col=colours[2])
	screen(3)
	par(mar=mar)
	hist(as.numeric(x$len2d[x$len2d>0]), breaks=breaks, main=titles[3], xlab="length", col=colours[3])
	close.screen(all=TRUE)

	# no need to return the data - they already have it


}
