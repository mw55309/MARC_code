plot.cumulative.yield <-
function(x,mar=c(4,4,3,0.5), titles=c("template","complement","2D"), colours=c("blue","yellow","red")) {

	# make sure we only look at valid data
	x <- x[!is.na(x$atime),]	

	# split into 1 row, 3 columns
	split.screen(c(1,3))

	# get the analysis time as a number
	alld <- as.numeric(x$atime)

	# order vector based on alld
	od <- order(alld)

	# sort it and sort x
	alld <- alld[od]
	x <- x[od,]

	# get the effective start time
	mind <- min(alld)

	
	# template lengths
	tlen <- x[,"tlen"]

	# complement lengths
	clen <- x[,"clen"]

	# 2D lengths
	dlen <- x[,"len2d"]

	# cumulative template, complement and 2d lengths
	# initiated with the first entry of each
	ctlen <- as.vector(tlen[1])
	cclen <- as.vector(clen[1])
	c2dlen <- as.vector(dlen[1])

	# times, relative to the effective start time
	# initiated with the first entry
	tplot <- as.vector(alld[1]-mind)

	# iterate over the rest
	for (i in 2:nrow(x)) {

		# update time and cumulative lengths
		tplot <- c(tplot, alld[i] - mind)
		ctlen <- c(ctlen, ctlen[length(ctlen)] + tlen[i])
		cclen <- c(cclen, cclen[length(cclen)] + clen[i])
		c2dlen <- c(c2dlen, c2dlen[length(c2dlen)] + dlen[i])

	}

	# plot the three graphs one after another
	screen(1)
	par(mar=mar)
	plot(tplot,ctlen/1000,type="l",xlab="time(seconds)", col=colours[1], main=titles[1], ylab="cumulative kbases", lwd=2)
	screen(2)
	par(mar=mar)
	plot(tplot,cclen/1000,type="l",xlab="time(seconds)", col=colours[2], main=titles[2], ylab="cumulative kbases", lwd=2)
	screen(3)
	par(mar=mar)
	plot(tplot,c2dlen/1000,type="l",xlab="time(seconds)", col=colours[3], main=titles[3], ylab="cumulative kbases", lwd=2)
	close.screen(all=TRUE)

	# return the data
	return(data.frame(time=tplot, cum.t=ctlen, cum.c=cclen, cum.2d=c2dlen))

}
