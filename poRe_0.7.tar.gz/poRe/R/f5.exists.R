f5.exists <- function(f5, group) {

	ret <- FALSE
	fid <- H5Fopen(f5)

	if (typeof(fid) != "S4") {
		return(ret)
	}

	ret <- H5Lexists(fid, group)
	H5Fclose(fid)

	return(ret)
}