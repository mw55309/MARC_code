read.fast5.info <-
function(dir) {

	# all fast5 files in dir
	f5files <- dir(path=dir, pattern="\\.fast5", full.names=TRUE)

	# run function get_fast5_info() on each entry in f5files
	myd <- t(sapply(f5files,get_fast5_info, simplify=TRUE))

	# set the column names
	colnames(myd) <- c("aname","atime","aversion","tlen","clen","len2d","tcevents","tmq","tnevents",
			"ccevents","cmq","cnevents","mq2d","sl2d","channel","asic_id",
			"asic_temp","device_id","exp_script","exp_start","flow_cell_id","heatsink_temp",
			"run_id","version_name")


	# convert to data frame
	myd <- as.data.frame(myd, stringsAsFactors=FALSE)

	# convert the text date to an actual date
	myd$atime <- strptime(myd$atime, format="%Y-%b-%d %H:%M:%S")

	# convert numeric columns
	for (n in c("tlen","clen","len2d","tcevents","tmq","tnevents","ccevents","cmq","cnevents","mq2d","sl2d","channel","asic_temp","heatsink_temp")) {
		myd[,n] <- as.numeric(myd[,n])
	}

	# set NA to zero where appropriate
	for (n in c("tlen","clen","len2d","tcevents","tnevents","ccevents","cnevents","sl2d")) {
		myd[,n][is.na(myd[,n])] <- 0
	}
	
	# return it
	return(myd)
}
